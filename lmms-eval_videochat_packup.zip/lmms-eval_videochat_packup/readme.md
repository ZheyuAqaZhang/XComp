1. 覆盖 lmms-eval_videochat 整个文件夹里的文件
2. 更改 evaluation_scripts/eval.sh 里的 CKPT_PATH
3. bash evaluation_scripts/eval.sh lvbench 1024 来测试
4. bash evaluation_scripts/all.sh 运行所有 benchmarks